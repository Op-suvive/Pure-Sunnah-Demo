import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Play, Clock, BookOpen } from "lucide-react";
import { toast } from "@/hooks/use-toast";

interface TimelinePoint {
  time: string;
  title: string;
  description: string;
  type: 'main' | 'verse' | 'hadith' | 'explanation';
}

interface LectureTimelineProps {
  points: TimelinePoint[];
  currentTime?: string;
}

export const LectureTimeline = ({ points, currentTime = "00:00" }: LectureTimelineProps) => {
  const handlePlayFromTime = (time: string, title: string) => {
    toast({
      title: "Playing from timeline",
      description: `Jumping to ${time}: ${title}`,
    });
  };
  const getTypeColor = (type: string) => {
    switch (type) {
      case 'verse': return 'bg-primary text-primary-foreground';
      case 'hadith': return 'bg-accent text-accent-foreground';
      case 'main': return 'bg-secondary text-secondary-foreground';
      default: return 'bg-muted text-muted-foreground';
    }
  };

  const getTypeIcon = (type: string) => {
    switch (type) {
      case 'verse': return <BookOpen className="w-3 h-3" />;
      case 'hadith': return <BookOpen className="w-3 h-3" />;
      default: return <Clock className="w-3 h-3" />;
    }
  };

  return (
    <Card className="p-6 shadow-gentle">
      <h3 className="text-lg font-semibold mb-4 flex items-center gap-2">
        <Clock className="w-5 h-5 text-primary" />
        Lecture Timeline
      </h3>
      
      <div className="space-y-4">
        {points.map((point, index) => (
          <div 
            key={index} 
            className="flex gap-4 group cursor-pointer hover:bg-secondary/50 p-3 rounded-lg transition-colors"
            onClick={() => handlePlayFromTime(point.time, point.title)}
          >
            {/* Timeline Line */}
            <div className="flex flex-col items-center">
              <div className={`w-8 h-8 rounded-full flex items-center justify-center ${getTypeColor(point.type)} shadow-sm`}>
                {getTypeIcon(point.type)}
              </div>
              {index !== points.length - 1 && (
                <div className="w-0.5 h-8 bg-border mt-2"></div>
              )}
            </div>
            
            {/* Content */}
            <div className="flex-1 min-w-0">
              <div className="flex items-center justify-between mb-2">
                <span className="text-sm font-medium text-primary">{point.time}</span>
                <Button 
                  variant="ghost" 
                  size="sm" 
                  className="opacity-0 group-hover:opacity-100 transition-opacity"
                  onClick={(e) => {
                    e.stopPropagation();
                    handlePlayFromTime(point.time, point.title);
                  }}
                >
                  <Play className="w-3 h-3" />
                </Button>
              </div>
              <h4 className="font-medium text-foreground mb-1">{point.title}</h4>
              <p className="text-sm text-muted-foreground">{point.description}</p>
            </div>
          </div>
        ))}
      </div>
      
      {/* Progress Indicator */}
      <div className="mt-6 pt-4 border-t border-border">
        <div className="flex items-center justify-between text-sm text-muted-foreground mb-2">
          <span>Current: {currentTime}</span>
          <span>Total: {points[points.length - 1]?.time || "00:00"}</span>
        </div>
        <div className="w-full bg-secondary rounded-full h-2">
          <div className="bg-primary h-2 rounded-full w-1/3 transition-all duration-300"></div>
        </div>
      </div>
    </Card>
  );
};