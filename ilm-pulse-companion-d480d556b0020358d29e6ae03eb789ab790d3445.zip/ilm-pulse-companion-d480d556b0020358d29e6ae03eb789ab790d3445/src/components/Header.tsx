import { Button } from "@/components/ui/button";
import { Globe, Mic, Library, Settings } from "lucide-react";
import { toast } from "@/hooks/use-toast";

interface HeaderProps {
  onNavigate?: (view: 'record' | 'library') => void;
}

export const Header = ({ onNavigate }: HeaderProps) => {
  const handleLanguageToggle = () => {
    toast({
      title: "Language Toggle",
      description: "Language switching functionality will be implemented soon",
    });
  };

  const handleSettings = () => {
    toast({
      title: "Settings",
      description: "Settings panel will be available soon",
    });
  };

  return (
    <header className="fixed top-0 left-0 right-0 z-50 bg-background/80 backdrop-blur-md border-b border-border">
      <div className="container mx-auto px-4 h-16 flex items-center justify-between">
        {/* Logo */}
        <div className="flex items-center gap-3 cursor-pointer" onClick={() => onNavigate?.('record')}>
          <div className="w-8 h-8 bg-gradient-primary rounded-lg flex items-center justify-center">
            <div className="w-4 h-4 bg-primary-foreground rounded-sm"></div>
          </div>
          <h1 className="text-xl font-bold bg-gradient-primary bg-clip-text text-transparent">
            Pure Sunnah
          </h1>
        </div>

        {/* Navigation */}
        <nav className="hidden md:flex items-center gap-6">
          <Button 
            variant="ghost" 
            size="sm" 
            className="gap-2"
            onClick={() => onNavigate?.('record')}
          >
            <Mic className="w-4 h-4" />
            Record
          </Button>
          <Button 
            variant="ghost" 
            size="sm" 
            className="gap-2"
            onClick={() => onNavigate?.('library')}
          >
            <Library className="w-4 h-4" />
            Library
          </Button>
          <Button 
            variant="ghost" 
            size="sm" 
            className="gap-2"
            onClick={handleLanguageToggle}
          >
            <Globe className="w-4 h-4" />
            العربية
          </Button>
        </nav>

        {/* Settings */}
        <Button variant="ghost" size="sm" onClick={handleSettings}>
          <Settings className="w-4 h-4" />
        </Button>
      </div>
    </header>
  );
};