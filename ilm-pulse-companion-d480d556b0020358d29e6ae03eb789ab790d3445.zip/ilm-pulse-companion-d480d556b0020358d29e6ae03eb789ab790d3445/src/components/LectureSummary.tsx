import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { BookOpen, Clock, MessageCircle, Bookmark, Share2 } from "lucide-react";
import { toast } from "@/hooks/use-toast";

interface LectureSummaryProps {
  title: string;
  scholar: string;
  duration: string;
  summary: string;
  keyPoints: string[];
  verses?: string[];
  hadith?: string[];
}

export const LectureSummary = ({ 
  title, 
  scholar, 
  duration, 
  summary, 
  keyPoints, 
  verses = [], 
  hadith = [] 
}: LectureSummaryProps) => {
  const handleBookmark = () => {
    toast({
      title: "Bookmarked",
      description: "Lecture has been saved to your library",
    });
  };

  const handleShare = () => {
    toast({
      title: "Share",
      description: "Sharing functionality will be available soon",
    });
  };

  const handleReflectionQuestion = (question: string) => {
    toast({
      title: "Reflection Question",
      description: `Exploring: "${question}"`,
    });
  };
  return (
    <div className="space-y-6">
      {/* Header */}
      <Card className="p-6 bg-gradient-secondary border-0 shadow-gentle">
        <div className="flex justify-between items-start mb-4">
          <div>
            <h2 className="text-2xl font-bold text-foreground mb-2">{title}</h2>
            <p className="text-muted-foreground">by {scholar}</p>
          </div>
          <div className="flex gap-2">
            <Button variant="ghost" size="sm" onClick={handleBookmark}>
              <Bookmark className="w-4 h-4" />
            </Button>
            <Button variant="ghost" size="sm" onClick={handleShare}>
              <Share2 className="w-4 h-4" />
            </Button>
          </div>
        </div>
        
        <div className="flex items-center gap-4 text-sm text-muted-foreground">
          <div className="flex items-center gap-1">
            <Clock className="w-4 h-4" />
            {duration}
          </div>
          <div className="flex items-center gap-1">
            <BookOpen className="w-4 h-4" />
            Arabic & English
          </div>
        </div>
      </Card>

      {/* Summary */}
      <Card className="p-6 shadow-gentle">
        <h3 className="text-lg font-semibold mb-4 flex items-center gap-2">
          <div className="w-2 h-2 bg-primary rounded-full"></div>
          Summary
        </h3>
        <p className="text-foreground leading-relaxed">{summary}</p>
      </Card>

      {/* Key Points */}
      <Card className="p-6 shadow-gentle">
        <h3 className="text-lg font-semibold mb-4 flex items-center gap-2">
          <div className="w-2 h-2 bg-accent rounded-full"></div>
          Key Points
        </h3>
        <ul className="space-y-3">
          {keyPoints.map((point, index) => (
            <li key={index} className="flex gap-3">
              <span className="w-6 h-6 bg-primary/10 text-primary rounded-full flex items-center justify-center text-sm font-medium flex-shrink-0 mt-0.5">
                {index + 1}
              </span>
              <span className="text-foreground">{point}</span>
            </li>
          ))}
        </ul>
      </Card>

      {/* Islamic References */}
      {(verses.length > 0 || hadith.length > 0) && (
        <div className="grid md:grid-cols-2 gap-4">
          {/* Quranic Verses */}
          {verses.length > 0 && (
            <Card className="p-6 shadow-gentle border-l-4 border-l-primary">
              <h3 className="text-lg font-semibold mb-4 text-primary">Quranic References</h3>
              <div className="space-y-3">
                {verses.map((verse, index) => (
                  <div key={index} className="bg-secondary/50 p-3 rounded-lg">
                    <p className="text-sm text-foreground">{verse}</p>
                  </div>
                ))}
              </div>
            </Card>
          )}

          {/* Hadith References */}
          {hadith.length > 0 && (
            <Card className="p-6 shadow-gentle border-l-4 border-l-accent">
              <h3 className="text-lg font-semibold mb-4 text-accent">Hadith References</h3>
              <div className="space-y-3">
                {hadith.map((hadithText, index) => (
                  <div key={index} className="bg-secondary/50 p-3 rounded-lg">
                    <p className="text-sm text-foreground">{hadithText}</p>
                  </div>
                ))}
              </div>
            </Card>
          )}
        </div>
      )}

      {/* Interactive Questions */}
      <Card className="p-6 shadow-gentle">
        <h3 className="text-lg font-semibold mb-4 flex items-center gap-2">
          <MessageCircle className="w-5 h-5 text-primary" />
          Reflection Questions
        </h3>
        <div className="space-y-3">
          <Button 
            variant="outline" 
            className="w-full justify-start h-auto p-4 text-left"
            onClick={() => handleReflectionQuestion("How does this teaching apply to modern life?")}
          >
            <div>
              <p className="font-medium">How does this teaching apply to modern life?</p>
              <p className="text-sm text-muted-foreground mt-1">Click to explore deeper</p>
            </div>
          </Button>
          <Button 
            variant="outline" 
            className="w-full justify-start h-auto p-4 text-left"
            onClick={() => handleReflectionQuestion("What are the practical steps mentioned?")}
          >
            <div>
              <p className="font-medium">What are the practical steps mentioned?</p>
              <p className="text-sm text-muted-foreground mt-1">Click to explore deeper</p>
            </div>
          </Button>
          <Button 
            variant="outline" 
            className="w-full justify-start h-auto p-4 text-left"
            onClick={() => handleReflectionQuestion("How does this connect to other Islamic principles?")}
          >
            <div>
              <p className="font-medium">How does this connect to other Islamic principles?</p>
              <p className="text-sm text-muted-foreground mt-1">Click to explore deeper</p>
            </div>
          </Button>
        </div>
      </Card>
    </div>
  );
};