import { useState } from "react";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Search, Filter, Calendar, User, Clock, BookmarkPlus } from "lucide-react";
import { toast } from "@/hooks/use-toast";

interface Lecture {
  id: string;
  title: string;
  scholar: string;
  duration: string;
  date: string;
  language: string;
  summary: string;
  topics: string[];
}

const mockLectures: Lecture[] = [
  {
    id: "1",
    title: "The Beauty of Patience in Islam",
    scholar: "Dr. Omar Suleiman",
    duration: "45:30",
    date: "2024-01-15",
    language: "English",
    summary: "A profound discussion on the concept of Sabr (patience) in Islamic teachings and its practical applications in daily life.",
    topics: ["Patience", "Character", "Spirituality"]
  },
  {
    id: "2",
    title: "Understanding Tawheed",
    scholar: "Sheikh Yasir Qadhi",
    duration: "32:15",
    date: "2024-01-12",
    language: "English",
    summary: "Deep dive into the fundamental Islamic concept of monotheism and its implications for believers.",
    topics: ["Tawheed", "Theology", "Foundation"]
  },
  {
    id: "3",
    title: "صلاة الخشوع",
    scholar: "الشيخ محمد راتب النابلسي",
    duration: "28:45",
    date: "2024-01-10",
    language: "Arabic",
    summary: "محاضرة عن الخشوع في الصلاة وكيفية تحقيقه في حياتنا اليومية",
    topics: ["Prayer", "Spirituality", "Khushoo"]
  }
];

interface PersonalLibraryProps {
  onNavigate?: (view: 'record' | 'summary') => void;
  onViewLecture?: (lectureId: string) => void;
}

export const PersonalLibrary = ({ onNavigate, onViewLecture }: PersonalLibraryProps) => {
  const [searchQuery, setSearchQuery] = useState("");

  const handleFilter = () => {
    toast({
      title: "Filter",
      description: "Advanced filtering options coming soon",
    });
  };

  const handleAddNew = () => {
    onNavigate?.('record');
  };

  const handleViewSummary = (lectureId: string, title: string) => {
    toast({
      title: "Opening lecture",
      description: `Loading summary for: ${title}`,
    });
    onViewLecture?.(lectureId);
  };

  const handleViewTimeline = (lectureId: string, title: string) => {
    toast({
      title: "Timeline view",
      description: `Loading timeline for: ${title}`,
    });
  };

  const filteredLectures = mockLectures.filter(lecture => 
    lecture.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
    lecture.scholar.toLowerCase().includes(searchQuery.toLowerCase()) ||
    lecture.topics.some(topic => topic.toLowerCase().includes(searchQuery.toLowerCase()))
  );
  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col md:flex-row gap-4 justify-between items-start md:items-center">
        <div>
          <h2 className="text-2xl font-bold text-foreground">Your Library</h2>
          <p className="text-muted-foreground">Access your saved lectures and summaries</p>
        </div>
        <div className="flex gap-2">
          <Button variant="outline" size="sm" onClick={handleFilter}>
            <Filter className="w-4 h-4" />
            Filter
          </Button>
          <Button variant="spiritual" size="sm" onClick={handleAddNew}>
            <BookmarkPlus className="w-4 h-4" />
            Add New
          </Button>
        </div>
      </div>

      {/* Search */}
      <Card className="p-4 shadow-gentle">
        <div className="relative">
          <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 w-4 h-4 text-muted-foreground" />
          <Input 
            placeholder="Search lectures, scholars, or topics..." 
            className="pl-10"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
          />
        </div>
      </Card>

      {/* Lecture Grid */}
      <div className="grid gap-4">
        {filteredLectures.map((lecture) => (
          <Card key={lecture.id} className="p-6 shadow-gentle hover:shadow-elevated transition-all duration-300 cursor-pointer group">
            <div className="flex flex-col md:flex-row gap-4">
              {/* Content */}
              <div className="flex-1">
                <div className="flex items-start justify-between mb-3">
                  <div>
                    <h3 className="text-lg font-semibold text-foreground group-hover:text-primary transition-colors">
                      {lecture.title}
                    </h3>
                    <p className="text-muted-foreground flex items-center gap-1">
                      <User className="w-3 h-3" />
                      {lecture.scholar}
                    </p>
                  </div>
                  <span className="text-xs bg-secondary px-2 py-1 rounded-full">
                    {lecture.language}
                  </span>
                </div>
                
                <p className="text-sm text-muted-foreground mb-4 line-clamp-2">
                  {lecture.summary}
                </p>
                
                {/* Topics */}
                <div className="flex flex-wrap gap-2 mb-4">
                  {lecture.topics.map((topic) => (
                    <span 
                      key={topic}
                      className="text-xs bg-primary/10 text-primary px-2 py-1 rounded-full"
                    >
                      {topic}
                    </span>
                  ))}
                </div>
                
                {/* Meta Info */}
                <div className="flex items-center gap-4 text-xs text-muted-foreground">
                  <div className="flex items-center gap-1">
                    <Clock className="w-3 h-3" />
                    {lecture.duration}
                  </div>
                  <div className="flex items-center gap-1">
                    <Calendar className="w-3 h-3" />
                    {new Date(lecture.date).toLocaleDateString()}
                  </div>
                </div>
              </div>
              
              {/* Actions */}
              <div className="flex md:flex-col gap-2">
                <Button 
                  variant="outline" 
                  size="sm" 
                  className="flex-1 md:flex-none"
                  onClick={(e) => {
                    e.stopPropagation();
                    handleViewSummary(lecture.id, lecture.title);
                  }}
                >
                  View Summary
                </Button>
                <Button 
                  variant="ghost" 
                  size="sm" 
                  className="flex-1 md:flex-none"
                  onClick={(e) => {
                    e.stopPropagation();
                    handleViewTimeline(lecture.id, lecture.title);
                  }}
                >
                  Timeline
                </Button>
              </div>
            </div>
          </Card>
        ))}
      </div>

      {/* Empty State or Load More */}
      {filteredLectures.length === 0 ? (
        searchQuery ? (
          <Card className="p-12 text-center shadow-gentle">
            <h3 className="text-lg font-semibold text-foreground mb-2">No results found</h3>
            <p className="text-muted-foreground mb-4">Try searching with different keywords</p>
            <Button variant="outline" onClick={() => setSearchQuery("")}>
              Clear Search
            </Button>
          </Card>
        ) : (
        <Card className="p-12 text-center shadow-gentle">
          <div className="w-16 h-16 bg-secondary rounded-full flex items-center justify-center mx-auto mb-4">
            <BookmarkPlus className="w-8 h-8 text-muted-foreground" />
          </div>
          <h3 className="text-lg font-semibold text-foreground mb-2">No lectures yet</h3>
          <p className="text-muted-foreground mb-4">Start by recording or uploading your first lecture</p>
          <Button variant="spiritual" onClick={handleAddNew}>
            Record First Lecture
          </Button>
        </Card>
        )
      ) : (
        <div className="text-center">
          <Button 
            variant="outline"
            onClick={() => toast({
              title: "Load More",
              description: "Loading additional lectures...",
            })}
          >
            Load More Lectures
          </Button>
        </div>
      )}
    </div>
  );
};