import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Upload, Mic, Play, Sparkles } from "lucide-react";
import { toast } from "@/hooks/use-toast";
import heroPattern from "@/assets/hero-pattern.jpg";

interface HeroSectionProps {
  onNavigate?: (view: 'record' | 'summary') => void;
}

export const HeroSection = ({ onNavigate }: HeroSectionProps) => {
  return (
    <section className="relative min-h-screen flex items-center justify-center overflow-hidden">
      {/* Background Pattern */}
      <div 
        className="absolute inset-0 bg-cover bg-center opacity-10"
        style={{ backgroundImage: `url(${heroPattern})` }}
      />
      <div className="absolute inset-0 bg-gradient-to-br from-background/95 via-background/90 to-background/95" />
      
      {/* Content */}
      <div className="relative z-10 container mx-auto px-4 text-center max-w-4xl">
        <div className="animate-fade-in">
          <div className="inline-flex items-center gap-2 bg-secondary/80 backdrop-blur-sm px-4 py-2 rounded-full text-sm text-muted-foreground mb-6">
            <Sparkles className="w-4 h-4 text-accent" />
            AI-Powered Islamic Learning
          </div>
          
          <h1 className="text-5xl md:text-7xl font-bold mb-6 leading-tight">
            <span className="bg-gradient-primary bg-clip-text text-transparent">
              Illuminate
            </span>
            <br />
            <span className="text-foreground">Islamic Knowledge</span>
          </h1>
          
          <p className="text-xl md:text-2xl text-muted-foreground mb-8 max-w-2xl mx-auto leading-relaxed">
            Record or upload lectures by Muslim scholars and get AI-powered summaries, 
            interactive questions, and spiritual insights - all in your preferred language.
          </p>
          
          {/* Action Cards */}
          <div className="grid md:grid-cols-2 gap-4 max-w-2xl mx-auto mb-8">
            <Card 
              className="p-6 bg-gradient-secondary border-0 shadow-gentle hover:shadow-elevated transition-all duration-300 hover:scale-105 cursor-pointer group"
              onClick={() => onNavigate?.('record')}
            >
              <div className="flex items-center gap-4">
                <div className="w-12 h-12 bg-primary/10 rounded-lg flex items-center justify-center group-hover:bg-primary/20 transition-colors">
                  <Mic className="w-6 h-6 text-primary" />
                </div>
                <div className="text-left">
                  <h3 className="font-semibold text-foreground">Record Live</h3>
                  <p className="text-sm text-muted-foreground">Start recording a lecture</p>
                </div>
              </div>
            </Card>
            
            <Card 
              className="p-6 bg-gradient-secondary border-0 shadow-gentle hover:shadow-elevated transition-all duration-300 hover:scale-105 cursor-pointer group"
              onClick={() => onNavigate?.('record')}
            >
              <div className="flex items-center gap-4">
                <div className="w-12 h-12 bg-accent/10 rounded-lg flex items-center justify-center group-hover:bg-accent/20 transition-colors">
                  <Upload className="w-6 h-6 text-accent" />
                </div>
                <div className="text-left">
                  <h3 className="font-semibold text-foreground">Upload Audio</h3>
                  <p className="text-sm text-muted-foreground">Import existing lectures</p>
                </div>
              </div>
            </Card>
          </div>
          
          {/* CTA Buttons */}
          <div className="flex flex-col sm:flex-row gap-4 justify-center items-center">
            <Button 
              variant="spiritual" 
              size="lg" 
              className="text-lg px-8 py-6"
              onClick={() => onNavigate?.('record')}
            >
              Start Learning
              <Play className="w-5 h-5" />
            </Button>
            <Button 
              variant="outline" 
              size="lg" 
              className="text-lg px-8 py-6"
              onClick={() => onNavigate?.('summary')}
            >
              View Sample
            </Button>
          </div>
          
          {/* Language Support */}
          <div className="mt-12 text-center">
            <p className="text-sm text-muted-foreground mb-3">
              Supported Languages
            </p>
            <div className="flex flex-wrap justify-center gap-3">
              {["العربية", "English", "اردو", "বাংলা"].map((lang) => (
                <span 
                  key={lang}
                  className="px-3 py-1 bg-secondary/60 rounded-full text-sm text-foreground"
                >
                  {lang}
                </span>
              ))}
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};