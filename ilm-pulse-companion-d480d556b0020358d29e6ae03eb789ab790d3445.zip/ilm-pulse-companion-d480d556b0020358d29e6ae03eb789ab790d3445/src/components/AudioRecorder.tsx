import { useState, useRef } from "react";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Mic, Square, Play, Pause, Upload } from "lucide-react";
import { toast } from "@/hooks/use-toast";

export const AudioRecorder = () => {
  const [isRecording, setIsRecording] = useState(false);
  const [isPlaying, setIsPlaying] = useState(false);
  const [recordingTime, setRecordingTime] = useState(0);
  const [audioBlob, setAudioBlob] = useState<Blob | null>(null);
  const [summary, setSummary] = useState("");
  const [isSummarizing, setIsSummarizing] = useState(false);
  const mediaRecorderRef = useRef<MediaRecorder | null>(null);
  const audioRef = useRef<HTMLAudioElement | null>(null);
  const timerRef = useRef<NodeJS.Timeout | null>(null);

  const startRecording = async () => {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      const mediaRecorder = new MediaRecorder(stream);
      mediaRecorderRef.current = mediaRecorder;

      const chunks: BlobPart[] = [];
      mediaRecorder.ondataavailable = (event) => {
        chunks.push(event.data);
      };

      mediaRecorder.onstop = () => {
        const blob = new Blob(chunks, { type: 'audio/wav' });
        setAudioBlob(blob);
        stream.getTracks().forEach(track => track.stop());
      };

      mediaRecorder.start();
      setIsRecording(true);
      setRecordingTime(0);

      timerRef.current = setInterval(() => {
        setRecordingTime(prev => prev + 1);
      }, 1000);

      toast({
        title: "Recording started",
        description: "Speak clearly for the best transcription quality",
      });
    } catch (error) {
      toast({
        title: "Recording failed",
        description: "Please allow microphone access to record",
        variant: "destructive"
      });
    }
  };

  const stopRecording = () => {
    if (mediaRecorderRef.current && isRecording) {
      mediaRecorderRef.current.stop();
      setIsRecording(false);
      if (timerRef.current) clearInterval(timerRef.current);
      toast({ title: "Recording saved", description: "Your lecture has been recorded successfully" });
    }
  };

  const playRecording = () => {
    if (audioBlob && audioRef.current) {
      const audioUrl = URL.createObjectURL(audioBlob);
      audioRef.current.src = audioUrl;
      audioRef.current.play();
      setIsPlaying(true);
    }
  };

  const pauseRecording = () => {
    if (audioRef.current) {
      audioRef.current.pause();
      setIsPlaying(false);
    }
  };

  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
  };

  const handleFileUpload = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (file) {
      setAudioBlob(file);
      toast({ title: "File uploaded", description: `${file.name} has been uploaded successfully` });
    }
  };

  const handleGenerateSummary = async () => {
    if (!audioBlob) return;
    setIsSummarizing(true);
    setSummary("");
    try {
      const TRANSCRIBE_API_URL = "https://router.huggingface.co/hf-inference/models/openai/whisper-large-v3-turbo";
      const formData = new FormData();
      formData.append("inputs", audioBlob, "audio.wav");

      const transcriptRes = await fetch(TRANSCRIBE_API_URL, {
        method: "POST",
        body: audioBlob,
        headers: {
          "Accept": "application/json",
          // HuggingFace expects the token WITHOUT 'Bearer '
          "Authorization": "Bearer your-huggingface-api-key", // Replace with your actual HuggingFace API key
        },
      });
      if (!transcriptRes.ok) throw new Error("Transcription failed: " + await transcriptRes.text());

      const transcriptData = await transcriptRes.json();
      const transcript = transcriptData.text || "";
      if (!transcript) throw new Error("No transcript returned");

      const SUMMARIZE_API_URL = "https://api.openai.com/v1/chat/completions";
      const summaryRes = await fetch(SUMMARIZE_API_URL, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          "Accept": "application/json",
          // OpenAI expects the token WITH 'Bearer '
          "Authorization": "Bearer sk-proj-your-openai-api-key", // Replace with your actual OpenAI API key
        },
        body: JSON.stringify({
          model: "gpt-3.5-turbo",
          messages: [
            { role: "system", content: "Give a general Translation. Give the general Points. Talk about any mentioned hadith's and Ayat's." },
            { role: "user", content: transcript }
          ]
        }),
      });
      if (!summaryRes.ok) throw new Error("Summarization failed: " + await summaryRes.text());

      const summaryData = await summaryRes.json();
      const summaryText = summaryData.choices?.[0]?.message?.content || "";
      setSummary(summaryText);
      toast({ title: "Summary generated!", description: "The summary is shown below." });
    } catch (err: any) {
      setSummary("");
      toast({
        title: "Summary failed",
        description: err.message || "Could not generate summary.",
        variant: "destructive",
      });
    } finally {
      setIsSummarizing(false);
    }
  };

  return (
    <Card className="p-8 bg-gradient-secondary border-0 shadow-gentle">
      <div className="text-center space-y-6">
        <h2 className="text-2xl font-bold text-foreground">Record or Upload Lecture</h2>

        {isRecording && (
          <div className="animate-pulse">
            <div className="w-4 h-4 bg-red-500 rounded-full mx-auto mb-2"></div>
            <p className="text-red-500 font-medium">Recording: {formatTime(recordingTime)}</p>
          </div>
        )}

        <div className="flex justify-center gap-4">
          {!isRecording ? (
            <Button variant="spiritual" size="lg" onClick={startRecording} className="gap-2">
              <Mic className="w-5 h-5" /> Start Recording
            </Button>
          ) : (
            <Button variant="destructive" size="lg" onClick={stopRecording} className="gap-2">
              <Square className="w-5 h-5" /> Stop Recording
            </Button>
          )}
        </div>

        {audioBlob && !isRecording && (
          <div className="space-y-4">
            <div className="flex justify-center gap-4">
              {!isPlaying ? (
                <Button variant="outline" onClick={playRecording} className="gap-2">
                  <Play className="w-4 h-4" /> Play Recording
                </Button>
              ) : (
                <Button variant="outline" onClick={pauseRecording} className="gap-2">
                  <Pause className="w-4 h-4" /> Pause
                </Button>
              )}
              <Button variant="gold" className="gap-2" onClick={handleGenerateSummary} disabled={isSummarizing}>
                {isSummarizing ? "Summarizing..." : "Generate Summary"}
              </Button>
            </div>
            {summary && (
              <div className="mt-6 p-4 bg-muted rounded shadow-inner">
                <h3 className="font-semibold mb-2">Summary</h3>
                <p className="whitespace-pre-line text-foreground">{summary}</p>
              </div>
            )}
          </div>
        )}

        <div className="border-t border-border pt-6">
          <p className="text-muted-foreground mb-4">Or upload an existing audio file</p>
          <div className="relative">
            <input
              type="file"
              accept="audio/*"
              onChange={handleFileUpload}
              className="absolute inset-0 w-full h-full opacity-0 cursor-pointer"
              id="audio-upload"
            />
            <Button variant="outline" className="gap-2" asChild>
              <label htmlFor="audio-upload">
                <Upload className="w-4 h-4" /> Upload Audio File
              </label>
            </Button>
          </div>
        </div>

        <audio ref={audioRef} onEnded={() => setIsPlaying(false)} className="hidden" />
      </div>
    </Card>
  );
};
