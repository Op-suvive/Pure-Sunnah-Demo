import { useState } from "react";
import { Header } from "@/components/Header";
import { HeroSection } from "@/components/HeroSection";
import { AudioRecorder } from "@/components/AudioRecorder";
import { LectureSummary } from "@/components/LectureSummary";
import { LectureTimeline } from "@/components/LectureTimeline";
import { PersonalLibrary } from "@/components/PersonalLibrary";

const Index = () => {
  const [currentView, setCurrentView] = useState<'home' | 'record' | 'summary' | 'library'>('home');

  // Mock data for demonstration
  const mockSummaryData = {
    title: "The Importance of Seeking Knowledge in Islam",
    scholar: "Dr. Bilal Philips",
    duration: "35:20",
    summary: "This lecture explores the fundamental Islamic principle that seeking knowledge is a religious obligation. Dr. Philips discusses how the pursuit of knowledge is deeply rooted in Islamic tradition, beginning with the first revelation 'Iqra' (Read), and explains the different types of knowledge that are emphasized in Islam - both religious and worldly knowledge that benefits humanity.",
    keyPoints: [
      "The first word revealed in the Quran was 'Iqra' (Read), emphasizing the importance of knowledge",
      "Islamic knowledge includes both religious sciences and beneficial worldly knowledge",
      "The Prophet (PBUH) said 'Seek knowledge from the cradle to the grave'",
      "Knowledge without action is incomplete - it must lead to righteous deeds",
      "Scholars hold a special position in Islam and are inheritors of the prophets"
    ],
    verses: [
      "Read! In the Name of your Lord who has created (all that exists). (Al-Alaq 96:1)",
      "And say: 'My Lord! Increase me in knowledge.' (Ta-Ha 20:114)"
    ],
    hadith: [
      "Whoever follows a path in the pursuit of knowledge, Allah will make a path to Paradise easy for him. (Muslim)"
    ]
  };

  const mockTimelineData = [
    { time: "00:00", title: "Introduction", description: "Opening remarks and context setting", type: "main" as const },
    { time: "02:30", title: "First Revelation", description: "Discussion of 'Iqra' and its significance", type: "verse" as const },
    { time: "08:15", title: "Types of Knowledge", description: "Religious vs worldly knowledge in Islam", type: "explanation" as const },
    { time: "15:45", title: "Prophetic Guidance", description: "Hadith about seeking knowledge", type: "hadith" as const },
    { time: "22:00", title: "Practical Application", description: "How to implement knowledge in daily life", type: "main" as const },
    { time: "30:10", title: "Status of Scholars", description: "The honored position of knowledge seekers", type: "explanation" as const }
  ];

  const renderCurrentView = () => {
    switch (currentView) {
      case 'record':
        return (
          <div className="container mx-auto px-4 py-8">
            <AudioRecorder />
          </div>
        );
      case 'summary':
        return (
          <div className="container mx-auto px-4 py-8">
            <div className="grid lg:grid-cols-3 gap-8">
              <div className="lg:col-span-2">
                <LectureSummary {...mockSummaryData} />
              </div>
              <div>
                <LectureTimeline points={mockTimelineData} currentTime="12:30" />
              </div>
            </div>
          </div>
        );
      case 'library':
        return (
          <div className="container mx-auto px-4 py-8">
            <PersonalLibrary 
              onNavigate={setCurrentView}
              onViewLecture={() => setCurrentView('summary')}
            />
          </div>
        );
      default:
        return <HeroSection onNavigate={setCurrentView} />;
    }
  };

  return (
    <div className="min-h-screen bg-background">
      <Header onNavigate={setCurrentView} />
      <main className="pt-16">
        {renderCurrentView()}
      </main>
      
      {/* Navigation Demo - Temporary for showcasing features */}
      {currentView !== 'home' && (
        <div className="fixed bottom-6 left-1/2 transform -translate-x-1/2 z-50">
          <div className="bg-card/90 backdrop-blur-md rounded-full px-4 py-2 shadow-elevated border">
            <div className="flex gap-2">
              <button 
                onClick={() => setCurrentView('home')}
                className="px-3 py-1 rounded-full text-sm hover:bg-secondary transition-colors"
              >
                Home
              </button>
              <button 
                onClick={() => setCurrentView('record')}
                className="px-3 py-1 rounded-full text-sm hover:bg-secondary transition-colors"
              >
                Record
              </button>
              <button 
                onClick={() => setCurrentView('summary')}
                className="px-3 py-1 rounded-full text-sm hover:bg-secondary transition-colors"
              >
                Summary
              </button>
              <button 
                onClick={() => setCurrentView('library')}
                className="px-3 py-1 rounded-full text-sm hover:bg-secondary transition-colors"
              >
                Library
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default Index;
